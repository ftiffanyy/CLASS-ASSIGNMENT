﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dt;
        string query;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =student;" + "pwd=isbmantap;" + "database=premier_league");
            dt = new DataTable();
            // 1 query = "select m.manager_name as `Nama Manager`, if(m.working = 1, concat(t.team_name, ', ', t.city), 'Available') as Kesanggupan from manager m left join team t on m.manager_id = t.manager_id or t.assmanager_id = m.manager_id;";
            // 2 query = "select m.manager_name as `Nama Manager`, if(m.working = 1, concat('Stadium ', t.home_stadium, ' (', t.city, ')'), concat('(', n.nation, ')')) as Alamat from manager m left join team t on m.manager_id = t.manager_id or t.assmanager_id = m.manager_id join nationality n on n.nationality_id = m.nationality_id;";
            // 3 query = "select t.team_name, concat(t.home_stadium, ' (', t.capacity, ')') as 'Stadium and Capacity', t.city as City, m.manager_name as `Manager Name`, m2.manager_name as `Assistant Manager` from team t, manager m, manager m2 where m.manager_id = t.manager_id and m2.manager_id = t.assmanager_id;";
            // 4 query = "select m.match_date as `Tanggal Pertandingan`, concat(t.team_name, 'vs', t2.team_name) as Pertandingan, concat(m.goal_home, '-', m.goal_away) as `Hasil Akhir`, if(m.goal_home = m.goal_away, 'Draw', if(m.goal_home > m.goal_away,concat(t.team_name, ' win'),concat(t2.team_name, ' win'))) as Kesimpulan from `match` m, team t, team t2 where m.team_home = t.team_id and m.team_away = t2.team_id;";
            query = "select t.team_name as `Nama Team`, concat(m.manager_name, ' & ', m2.manager_name) as `Manager & Assistant Manager`, p.player_name as `Nama Captain` from team t, manager m, manager m2, player p where m.manager_id = t.manager_id and m2.manager_id = t.assmanager_id and t.captain_id = p.player_id;";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt);
            dgv.DataSource = dt;
        }
    }
}
