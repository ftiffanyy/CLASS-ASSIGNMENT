﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_angka1 = new System.Windows.Forms.Label();
            this.tb_angka1 = new System.Windows.Forms.TextBox();
            this.btn_hitung = new System.Windows.Forms.Button();
            this.lb_angka2 = new System.Windows.Forms.Label();
            this.rbtn_tambah = new System.Windows.Forms.RadioButton();
            this.rbtn_kurang = new System.Windows.Forms.RadioButton();
            this.rbtn_kali = new System.Windows.Forms.RadioButton();
            this.rbtn_bagi = new System.Windows.Forms.RadioButton();
            this.tb_angka2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_hasil = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_angka1
            // 
            this.lb_angka1.AutoSize = true;
            this.lb_angka1.Location = new System.Drawing.Point(12, 25);
            this.lb_angka1.Name = "lb_angka1";
            this.lb_angka1.Size = new System.Drawing.Size(47, 13);
            this.lb_angka1.TabIndex = 0;
            this.lb_angka1.Text = "Angka 1";
            this.lb_angka1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tb_angka1
            // 
            this.tb_angka1.Location = new System.Drawing.Point(65, 22);
            this.tb_angka1.Name = "tb_angka1";
            this.tb_angka1.Size = new System.Drawing.Size(100, 20);
            this.tb_angka1.TabIndex = 1;
            // 
            // btn_hitung
            // 
            this.btn_hitung.Location = new System.Drawing.Point(65, 71);
            this.btn_hitung.Name = "btn_hitung";
            this.btn_hitung.Size = new System.Drawing.Size(75, 23);
            this.btn_hitung.TabIndex = 2;
            this.btn_hitung.Text = "Hitung";
            this.btn_hitung.UseVisualStyleBackColor = true;
            this.btn_hitung.Click += new System.EventHandler(this.btn_ganti_Click);
            // 
            // lb_angka2
            // 
            this.lb_angka2.AutoSize = true;
            this.lb_angka2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lb_angka2.Location = new System.Drawing.Point(12, 48);
            this.lb_angka2.Name = "lb_angka2";
            this.lb_angka2.Size = new System.Drawing.Size(47, 13);
            this.lb_angka2.TabIndex = 3;
            this.lb_angka2.Text = "Angka 2";
            this.lb_angka2.Click += new System.EventHandler(this.lb_ganti_Click);
            // 
            // rbtn_tambah
            // 
            this.rbtn_tambah.AutoSize = true;
            this.rbtn_tambah.Location = new System.Drawing.Point(210, 19);
            this.rbtn_tambah.Name = "rbtn_tambah";
            this.rbtn_tambah.Size = new System.Drawing.Size(86, 17);
            this.rbtn_tambah.TabIndex = 4;
            this.rbtn_tambah.TabStop = true;
            this.rbtn_tambah.Text = "Penjumlahan";
            this.rbtn_tambah.UseVisualStyleBackColor = true;
            // 
            // rbtn_kurang
            // 
            this.rbtn_kurang.AutoSize = true;
            this.rbtn_kurang.Location = new System.Drawing.Point(210, 42);
            this.rbtn_kurang.Name = "rbtn_kurang";
            this.rbtn_kurang.Size = new System.Drawing.Size(89, 17);
            this.rbtn_kurang.TabIndex = 5;
            this.rbtn_kurang.TabStop = true;
            this.rbtn_kurang.Text = "Pengurangan";
            this.rbtn_kurang.UseVisualStyleBackColor = true;
            // 
            // rbtn_kali
            // 
            this.rbtn_kali.AutoSize = true;
            this.rbtn_kali.Location = new System.Drawing.Point(210, 65);
            this.rbtn_kali.Name = "rbtn_kali";
            this.rbtn_kali.Size = new System.Drawing.Size(69, 17);
            this.rbtn_kali.TabIndex = 6;
            this.rbtn_kali.TabStop = true;
            this.rbtn_kali.Text = "Perkalian";
            this.rbtn_kali.UseVisualStyleBackColor = true;
            // 
            // rbtn_bagi
            // 
            this.rbtn_bagi.AutoSize = true;
            this.rbtn_bagi.Location = new System.Drawing.Point(210, 88);
            this.rbtn_bagi.Name = "rbtn_bagi";
            this.rbtn_bagi.Size = new System.Drawing.Size(78, 17);
            this.rbtn_bagi.TabIndex = 7;
            this.rbtn_bagi.TabStop = true;
            this.rbtn_bagi.Text = "Pembagian";
            this.rbtn_bagi.UseVisualStyleBackColor = true;
            // 
            // tb_angka2
            // 
            this.tb_angka2.Location = new System.Drawing.Point(65, 45);
            this.tb_angka2.Name = "tb_angka2";
            this.tb_angka2.Size = new System.Drawing.Size(100, 20);
            this.tb_angka2.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Hasil";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lb_hasil
            // 
            this.lb_hasil.AutoSize = true;
            this.lb_hasil.Location = new System.Drawing.Point(76, 118);
            this.lb_hasil.Name = "lb_hasil";
            this.lb_hasil.Size = new System.Drawing.Size(25, 13);
            this.lb_hasil.TabIndex = 10;
            this.lb_hasil.Text = "000";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 260);
            this.Controls.Add(this.lb_hasil);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_angka2);
            this.Controls.Add(this.rbtn_bagi);
            this.Controls.Add(this.rbtn_kali);
            this.Controls.Add(this.rbtn_kurang);
            this.Controls.Add(this.rbtn_tambah);
            this.Controls.Add(this.lb_angka2);
            this.Controls.Add(this.btn_hitung);
            this.Controls.Add(this.tb_angka1);
            this.Controls.Add(this.lb_angka1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_angka1;
        private System.Windows.Forms.TextBox tb_angka1;
        private System.Windows.Forms.Button btn_hitung;
        private System.Windows.Forms.Label lb_angka2;
        private System.Windows.Forms.RadioButton rbtn_tambah;
        private System.Windows.Forms.RadioButton rbtn_kurang;
        private System.Windows.Forms.RadioButton rbtn_kali;
        private System.Windows.Forms.RadioButton rbtn_bagi;
        private System.Windows.Forms.TextBox tb_angka2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_hasil;
    }
}

