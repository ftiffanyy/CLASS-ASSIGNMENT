﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lb_ganti_Click(object sender, EventArgs e)
        {

        }

        private void btn_ganti_Click(object sender, EventArgs e)
        {
            int angka1 = Convert.ToInt32(tb_angka1.Text);
            int angka2 = Convert.ToInt32(tb_angka2.Text);
            if(angka1 < angka2)
            {
                MessageBox.Show("Angka 1 harus lebih besar dari Angka 2");
            }
            if (rbtn_tambah.Checked == true)
            {
                int hasil = angka1 + angka2;
                lb_hasil.Text = Convert.ToString(hasil);
            }
            else if (rbtn_kurang.Checked == true)
            {
                int hasil = angka1 - angka2;
                lb_hasil.Text = Convert.ToString(hasil);
            }
            else if (rbtn_kali.Checked == true)
            {
                int hasil = angka1 * angka2;
                lb_hasil.Text = Convert.ToString(hasil);
            }
            else if (rbtn_bagi.Checked == true)
            {
                int hasil = angka1 / angka2;
                lb_hasil.Text = Convert.ToString(hasil);
            }
            else
            {
                MessageBox.Show("Error, Mode tidak dipilih");
            }
        }
        

        private void rbtn_merah_CheckedChanged(object sender, EventArgs e)
        {
            lb_angka2.ForeColor = Color.Red;
        }

        private void rbtn_kuning_CheckedChanged(object sender, EventArgs e)
        {
            lb_angka2.ForeColor = Color.Yellow;
        }

        private void rbtn_hijau_CheckedChanged(object sender, EventArgs e)
        {
            lb_angka2.ForeColor = Color.Green;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
