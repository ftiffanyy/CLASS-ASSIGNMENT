﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dt; DataTable dtteam; DataTable dtaway; DataTable player; DataTable dmatch; DataTable manager; DataTable match; DataTable dt2; DataTable dt3;
        string query; string idhome; string idaway; string idmhome; string idmaway; string captain1; string captain2; int index; string id;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =root;" + "pwd=isbmantap;" + "database=premier_league");
            dtteam = new DataTable(); dtaway = new DataTable(); dt2 = new DataTable();
            query = "select * from team t";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam); sqlDataAdapter.Fill(dtaway); sqlDataAdapter.Fill(dt2);

            match = new DataTable();
            query = "select * from `match`";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(match);

            dmatch = new DataTable();
            query = "select * from dmatch";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dmatch);

            manager = new DataTable();
            query = "select * from manager";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(manager);

            player = new DataTable();
            query = "select * from player";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(player);

            cb_away.DataSource = dtaway;
            cb_away.DisplayMember = "team_name";
            cb_away.ValueMember = "team_id";

            cb_home.DataSource = dtteam;
            cb_home.ValueMember = "team_id";
            cb_home.DisplayMember = "team_name";



            dt = new DataTable();
            dt.Columns.Add("minute");
            dt.Columns.Add("Player Name 1");
            dt.Columns.Add("Tipe 1");
            dt.Columns.Add("Player Name 2");
            dt.Columns.Add("Tipe 2");
        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex == -1 && cb_away.SelectedIndex == -1)
            {
                
            }
            else
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home dan Team Away tidak boleh sama");
                }
                else if (cb_away.Text != cb_home.Text)
                {
                    idhome = cb_home.SelectedValue.ToString();
                    for (int i = 0; i < dtteam.Rows.Count; i++)
                    {
                        if (dtteam.Rows[i][0].ToString() == idhome)
                        {
                            idmhome = dtteam.Rows[i][5].ToString();
                            captain1 = dtteam.Rows[i][7].ToString();
                            lbl_stadium.Text = $"Stadium : {dtteam.Rows[i][2].ToString()}";
                            lbl_capacity.Text = $"Capacity : {dtteam.Rows[i][3].ToString()}";
                        }
                    }
                    for (int i = 0; i < manager.Rows.Count; i++)
                    {
                        if (manager.Rows[i][0].ToString() == idmhome)
                        {
                            lbl_managerhome.Text = $"Manager : {manager.Rows[i][1].ToString()}";
                        }
                    }
                    for (int i = 0; i < player.Rows.Count; i++)
                    {
                        if (player.Rows[i][0].ToString() == captain1)
                        {
                            lbl_captainhome.Text = $"Captain : {player.Rows[i][2].ToString()}";
                        }
                    }
                }
            }
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex == -1 && cb_away.SelectedIndex == -1)
            {
                
            }
            else
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home dan Team Away tidak boleh sama");
                }
                else if (cb_away.Text != cb_home.Text)
                {
                    idaway = cb_away.SelectedValue.ToString();
                    for (int i = 0; i < dtteam.Rows.Count; i++)
                    {
                        if (dtteam.Rows[i][0].ToString() == idaway)
                        {
                            idmaway = dtteam.Rows[i][5].ToString();
                            captain2 = dtteam.Rows[i][7].ToString();
                        }
                    }
                    for (int i = 0; i < manager.Rows.Count; i++)
                    {
                        if (manager.Rows[i][0].ToString() == idmaway)
                        {
                            lbl_manageraway.Text = $"Manager : {manager.Rows[i][1].ToString()}";
                        }
                    }
                    for (int i = 0; i < player.Rows.Count; i++)
                    {
                        if (player.Rows[i][0].ToString() == captain2)
                        {
                            lbl_captainaway.Text = $"Captain : {player.Rows[i][2].ToString()}";
                        }
                    }
                }
            }
        }

        private void bt_check_Click(object sender, EventArgs e)
        {
            bool yn = false; dt3 = new DataTable();
            for (int i = 0;i < match.Rows.Count;i++)
            {
                if (match.Rows[i][2].ToString() == cb_home.SelectedValue.ToString() && match.Rows[i][3].ToString() == cb_away.SelectedValue.ToString())
                {
                    index = i;
                    yn = true;
                    break;
                }
            }
            if(yn)
            {
                lbl_tgl.Text = $"Tanggal : {match.Rows[index][1].ToString()}";
                lbl_skor.Text = $"Skor :  {match.Rows[index][4].ToString()} : {match.Rows[index][5].ToString()}";

                query = "select d.minute, p.player_name, d.type, d.team_id from dmatch d join player p on p.player_id = d.player_id order by 1;";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt3);

                for(int i = 0; i < dt3.Rows.Count; i++)
                {
                    if (dt3.Rows[i][3].ToString() == cb_home.SelectedValue.ToString())
                    {
                        dt.Rows.Add(dt3.Rows[i][0].ToString(), dt3.Rows[i][1].ToString(), dt3.Rows[i][2].ToString(), " ", " ");
                    }
                    if (dt3.Rows[i][3].ToString() == cb_away.SelectedValue.ToString())
                    {
                        dt.Rows.Add(dt3.Rows[i][0].ToString(), " ", " ", dt3.Rows[i][1].ToString(), dt3.Rows[i][2].ToString());
                    }
                }
                dgv.DataSource = dt;
            }
            else if (yn == false)
            {
                MessageBox.Show("tidak ada");
            }
        }
    }
}
