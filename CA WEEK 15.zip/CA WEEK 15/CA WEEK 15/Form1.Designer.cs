﻿namespace CA_WEEK_15
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_home = new System.Windows.Forms.ComboBox();
            this.cb_away = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_managerhome = new System.Windows.Forms.Label();
            this.lbl_captainhome = new System.Windows.Forms.Label();
            this.lbl_manageraway = new System.Windows.Forms.Label();
            this.lbl_captainaway = new System.Windows.Forms.Label();
            this.lbl_stadium = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.lbl_capacity = new System.Windows.Forms.Label();
            this.bt_check = new System.Windows.Forms.Button();
            this.lbl_tgl = new System.Windows.Forms.Label();
            this.lbl_skor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_home
            // 
            this.cb_home.FormattingEnabled = true;
            this.cb_home.Location = new System.Drawing.Point(40, 35);
            this.cb_home.Name = "cb_home";
            this.cb_home.Size = new System.Drawing.Size(234, 33);
            this.cb_home.TabIndex = 0;
            this.cb_home.SelectedIndexChanged += new System.EventHandler(this.cb_home_SelectedIndexChanged);
            // 
            // cb_away
            // 
            this.cb_away.FormattingEnabled = true;
            this.cb_away.Location = new System.Drawing.Point(1018, 35);
            this.cb_away.Name = "cb_away";
            this.cb_away.Size = new System.Drawing.Size(234, 33);
            this.cb_away.TabIndex = 1;
            this.cb_away.SelectedIndexChanged += new System.EventHandler(this.cb_away_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(623, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "VS";
            // 
            // lbl_managerhome
            // 
            this.lbl_managerhome.AutoSize = true;
            this.lbl_managerhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_managerhome.Location = new System.Drawing.Point(35, 95);
            this.lbl_managerhome.Name = "lbl_managerhome";
            this.lbl_managerhome.Size = new System.Drawing.Size(44, 29);
            this.lbl_managerhome.TabIndex = 3;
            this.lbl_managerhome.Text = "VS";
            // 
            // lbl_captainhome
            // 
            this.lbl_captainhome.AutoSize = true;
            this.lbl_captainhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_captainhome.Location = new System.Drawing.Point(35, 159);
            this.lbl_captainhome.Name = "lbl_captainhome";
            this.lbl_captainhome.Size = new System.Drawing.Size(44, 29);
            this.lbl_captainhome.TabIndex = 4;
            this.lbl_captainhome.Text = "VS";
            // 
            // lbl_manageraway
            // 
            this.lbl_manageraway.AutoSize = true;
            this.lbl_manageraway.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_manageraway.Location = new System.Drawing.Point(1013, 95);
            this.lbl_manageraway.Name = "lbl_manageraway";
            this.lbl_manageraway.Size = new System.Drawing.Size(44, 29);
            this.lbl_manageraway.TabIndex = 5;
            this.lbl_manageraway.Text = "VS";
            // 
            // lbl_captainaway
            // 
            this.lbl_captainaway.AutoSize = true;
            this.lbl_captainaway.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_captainaway.Location = new System.Drawing.Point(1013, 159);
            this.lbl_captainaway.Name = "lbl_captainaway";
            this.lbl_captainaway.Size = new System.Drawing.Size(44, 29);
            this.lbl_captainaway.TabIndex = 6;
            this.lbl_captainaway.Text = "VS";
            // 
            // lbl_stadium
            // 
            this.lbl_stadium.AutoSize = true;
            this.lbl_stadium.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_stadium.Location = new System.Drawing.Point(521, 197);
            this.lbl_stadium.Name = "lbl_stadium";
            this.lbl_stadium.Size = new System.Drawing.Size(0, 29);
            this.lbl_stadium.TabIndex = 7;
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(12, 444);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 82;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.Size = new System.Drawing.Size(1334, 502);
            this.dgv.TabIndex = 8;
            // 
            // lbl_capacity
            // 
            this.lbl_capacity.AutoSize = true;
            this.lbl_capacity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_capacity.Location = new System.Drawing.Point(521, 246);
            this.lbl_capacity.Name = "lbl_capacity";
            this.lbl_capacity.Size = new System.Drawing.Size(0, 29);
            this.lbl_capacity.TabIndex = 9;
            // 
            // bt_check
            // 
            this.bt_check.Location = new System.Drawing.Point(581, 293);
            this.bt_check.Name = "bt_check";
            this.bt_check.Size = new System.Drawing.Size(125, 44);
            this.bt_check.TabIndex = 10;
            this.bt_check.Text = "Check";
            this.bt_check.UseVisualStyleBackColor = true;
            this.bt_check.Click += new System.EventHandler(this.bt_check_Click);
            // 
            // lbl_tgl
            // 
            this.lbl_tgl.AutoSize = true;
            this.lbl_tgl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tgl.Location = new System.Drawing.Point(521, 352);
            this.lbl_tgl.Name = "lbl_tgl";
            this.lbl_tgl.Size = new System.Drawing.Size(0, 29);
            this.lbl_tgl.TabIndex = 11;
            // 
            // lbl_skor
            // 
            this.lbl_skor.AutoSize = true;
            this.lbl_skor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_skor.Location = new System.Drawing.Point(556, 395);
            this.lbl_skor.Name = "lbl_skor";
            this.lbl_skor.Size = new System.Drawing.Size(0, 29);
            this.lbl_skor.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 958);
            this.Controls.Add(this.lbl_skor);
            this.Controls.Add(this.lbl_tgl);
            this.Controls.Add(this.bt_check);
            this.Controls.Add(this.lbl_capacity);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.lbl_stadium);
            this.Controls.Add(this.lbl_captainaway);
            this.Controls.Add(this.lbl_manageraway);
            this.Controls.Add(this.lbl_captainhome);
            this.Controls.Add(this.lbl_managerhome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_away);
            this.Controls.Add(this.cb_home);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_home;
        private System.Windows.Forms.ComboBox cb_away;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_managerhome;
        private System.Windows.Forms.Label lbl_captainhome;
        private System.Windows.Forms.Label lbl_manageraway;
        private System.Windows.Forms.Label lbl_captainaway;
        private System.Windows.Forms.Label lbl_stadium;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label lbl_capacity;
        private System.Windows.Forms.Button bt_check;
        private System.Windows.Forms.Label lbl_tgl;
        private System.Windows.Forms.Label lbl_skor;
    }
}

