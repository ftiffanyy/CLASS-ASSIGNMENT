﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_Week_11
{
    //felicia tiffany 0706022310032
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtplayer;
        DataTable dt2; DataTable dt3;
        DataTable dt4;

        private void bt_login_Click(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection($"server ={tb_server.Text};uid={tb_user.Text};pwd={tb_pass.Text};database={tb_database.Text}");
            sqlConnect.Open();
            sqlConnect.Close();
            dtplayer = new DataTable();
            string sqlquery = $"Select dmatch.minute, team.team_name, player.player_name, dmatch.type\r\nfrom dmatch, team, player, `match` m\r\nwhere dmatch.match_id = m.match_id and player.player_id = dmatch.player_id and dmatch.team_id = team.team_id\r\nand (m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}')\r\norder by 1;";
            sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);
            dgv_team.DataSource = dtplayer;

            dt2 = new DataTable();
            dt3 = new DataTable();
            string sqlq = "Select team_id, team_name\r\nfrom team";
            sqlCommand = new MySqlCommand(sqlq, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dt2);
            sqlDataAdapter.Fill(dt3);
            cb_teamhome.DataSource = dt2;
            cb_teamhome.DisplayMember = "team_name";
            cb_teamhome.ValueMember = "team_id";

            cb_teamaway.DataSource = dt3;
            cb_teamaway.DisplayMember = "team_name";
            cb_teamaway.ValueMember = "team_id";
        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamhome.SelectedIndex != 0 && cb_teamaway.SelectedIndex != 0)
            {
                dt4 = new DataTable();
                string sqlquery = $"Select dmatch.minute, team.team_name, player.player_name, dmatch.type\r\nfrom dmatch, team, player, `match` m\r\nwhere dmatch.match_id = m.match_id and player.player_id = dmatch.player_id and dmatch.team_id = team.team_id\r\nand (m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}')\r\norder by 1;";
                sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtplayer);
                dgv_team.DataSource = dtplayer;

                string sqlquery2 = $"SELECT m.match_date\r\nfrom `match` m\r\nwhere (m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}');";
                sqlCommand = new MySqlCommand(sqlquery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt4);
                if (dt4.Rows.Count != 0)
                {
                    dtp_date.Value = Convert.ToDateTime(dt4.Rows[0][0]);
                }
            }

        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamhome.SelectedIndex != 0 && cb_teamaway.SelectedIndex != 0)
            {
                dt4 = new DataTable();
                string sqlquery = $"Select dmatch.minute, team.team_name, player.player_name, dmatch.type\r\nfrom dmatch, team, player, `match` m\r\nwhere dmatch.match_id = m.match_id and player.player_id = dmatch.player_id and dmatch.team_id = team.team_id\r\nand (m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}')\r\norder by 1;";
                sqlCommand = new MySqlCommand(sqlquery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtplayer);
                dgv_team.DataSource = dtplayer;

                string sqlquery2 = $"SELECT m.match_date\r\nfrom `match` m\r\nwhere (m.team_home = '{cb_teamhome.SelectedValue}' AND m.team_away = '{cb_teamaway.SelectedValue}');";
                sqlCommand = new MySqlCommand(sqlquery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dt4);
                dtp_date.Value = Convert.ToDateTime(dt4.Rows[0][0]);
                if (dt4.Rows.Count != 0)
                {
                    dtp_date.Value = Convert.ToDateTime(dt4.Rows[0][0]);
                }
            }
        }
    }
        
}
