﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_week_5
{
    public partial class Form1 : Form
    {
        DataTable dt;
        string id;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("ID Tim");
            dt.Columns.Add("Nama Tim");
            dt.Columns.Add("Nama Stadium");
            dt.Columns.Add("Kapasitas");
            dt.Columns.Add("Kota");
            dt.Columns.Add("Nama Manager");
            data.DataSource = dt;
            tb_id.Enabled = false;
        }

        private void bt_input_Click(object sender, EventArgs e)
        {
            string tim = tb_tim.Text;
            string stadium = tb_stadium.Text;
            string kapasitas = tb_kapasitas.Text;
            string kota = tb_kota.Text;
            string manager = tb_manager.Text;
            bool yn = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][1].ToString() == tim)
                {
                    yn = true;
                    break;
                }
            }
            if (yn == true)
            {
                MessageBox.Show("Nama Tim Sama");
            }
            bool tf = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][2].ToString() == stadium)
                {
                    tf = true;
                    break;
                }
            }
            if (tf == true)
            {
                MessageBox.Show("Nama Stadium Sama");
            }
            bool staf = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][5].ToString() == manager)
                {
                    staf = true;
                    break;
                }
            }
            if (staf == true)
            {
                MessageBox.Show("Nama Manager Sama");
            }
            if (!yn && !tf && !staf)
            {
                dt.Rows.Add(id.ToUpper(), tim, stadium, kapasitas, kota, manager);
            }
            tb_id.Text = ""; tb_tim.Text = ""; tb_stadium.Text = ""; tb_kota.Text = ""; tb_kapasitas.Text = ""; tb_manager.Text = "";
        }

        private void tb_tim_TextChanged(object sender, EventArgs e)
        {
            int counter = 1;
            if (tb_tim.Text == "")
            {
                tb_id.Text = "";
            }
            else if (dt.Rows.Count == 0)
            {
                id = tb_tim.Text[0] + "0" + counter;
                tb_id.Text = id;
            }
            else if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1].ToString()[0] == tb_tim.Text[0])
                    {
                        counter++;
                    }
                }
                if (counter < 10)
                {
                    id = tb_tim.Text[0] + "0" + counter;
                    tb_id.Text = id.ToUpper();
                }
                else if (counter >= 10)
                {
                    id = tb_tim.Text[0] + "1" + counter;
                    tb_id.Text = id.ToUpper();
                }
            }
        }
    }
}
