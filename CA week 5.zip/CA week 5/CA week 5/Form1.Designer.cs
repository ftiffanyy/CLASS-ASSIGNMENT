﻿namespace CA_week_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_nama = new System.Windows.Forms.Label();
            this.lbl_stadium = new System.Windows.Forms.Label();
            this.lbl_kapasitas = new System.Windows.Forms.Label();
            this.lbl_kota = new System.Windows.Forms.Label();
            this.lbl_manager = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.tb_tim = new System.Windows.Forms.TextBox();
            this.tb_stadium = new System.Windows.Forms.TextBox();
            this.tb_kapasitas = new System.Windows.Forms.TextBox();
            this.tb_kota = new System.Windows.Forms.TextBox();
            this.tb_manager = new System.Windows.Forms.TextBox();
            this.bt_input = new System.Windows.Forms.Button();
            this.data = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.data)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_id
            // 
            this.lbl_id.AutoEllipsis = true;
            this.lbl_id.AutoSize = true;
            this.lbl_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_id.Location = new System.Drawing.Point(65, 51);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(84, 29);
            this.lbl_id.TabIndex = 0;
            this.lbl_id.Text = "Tim ID";
            // 
            // lbl_nama
            // 
            this.lbl_nama.AutoEllipsis = true;
            this.lbl_nama.AutoSize = true;
            this.lbl_nama.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nama.Location = new System.Drawing.Point(65, 91);
            this.lbl_nama.Name = "lbl_nama";
            this.lbl_nama.Size = new System.Drawing.Size(125, 29);
            this.lbl_nama.TabIndex = 1;
            this.lbl_nama.Text = "Nama Tim";
            // 
            // lbl_stadium
            // 
            this.lbl_stadium.AutoEllipsis = true;
            this.lbl_stadium.AutoSize = true;
            this.lbl_stadium.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_stadium.Location = new System.Drawing.Point(65, 130);
            this.lbl_stadium.Name = "lbl_stadium";
            this.lbl_stadium.Size = new System.Drawing.Size(171, 29);
            this.lbl_stadium.TabIndex = 2;
            this.lbl_stadium.Text = "Nama Stadium";
            // 
            // lbl_kapasitas
            // 
            this.lbl_kapasitas.AutoEllipsis = true;
            this.lbl_kapasitas.AutoSize = true;
            this.lbl_kapasitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kapasitas.Location = new System.Drawing.Point(65, 170);
            this.lbl_kapasitas.Name = "lbl_kapasitas";
            this.lbl_kapasitas.Size = new System.Drawing.Size(118, 29);
            this.lbl_kapasitas.TabIndex = 3;
            this.lbl_kapasitas.Text = "Kapasitas";
            // 
            // lbl_kota
            // 
            this.lbl_kota.AutoEllipsis = true;
            this.lbl_kota.AutoSize = true;
            this.lbl_kota.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kota.Location = new System.Drawing.Point(65, 211);
            this.lbl_kota.Name = "lbl_kota";
            this.lbl_kota.Size = new System.Drawing.Size(62, 29);
            this.lbl_kota.TabIndex = 4;
            this.lbl_kota.Text = "Kota";
            // 
            // lbl_manager
            // 
            this.lbl_manager.AutoEllipsis = true;
            this.lbl_manager.AutoSize = true;
            this.lbl_manager.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_manager.Location = new System.Drawing.Point(65, 255);
            this.lbl_manager.Name = "lbl_manager";
            this.lbl_manager.Size = new System.Drawing.Size(178, 29);
            this.lbl_manager.TabIndex = 5;
            this.lbl_manager.Text = "Nama Manager";
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(358, 49);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(189, 31);
            this.tb_id.TabIndex = 6;
            // 
            // tb_tim
            // 
            this.tb_tim.Location = new System.Drawing.Point(358, 86);
            this.tb_tim.Name = "tb_tim";
            this.tb_tim.Size = new System.Drawing.Size(189, 31);
            this.tb_tim.TabIndex = 7;
            this.tb_tim.TextChanged += new System.EventHandler(this.tb_tim_TextChanged);
            // 
            // tb_stadium
            // 
            this.tb_stadium.Location = new System.Drawing.Point(358, 128);
            this.tb_stadium.Name = "tb_stadium";
            this.tb_stadium.Size = new System.Drawing.Size(189, 31);
            this.tb_stadium.TabIndex = 8;
            // 
            // tb_kapasitas
            // 
            this.tb_kapasitas.Location = new System.Drawing.Point(358, 170);
            this.tb_kapasitas.Name = "tb_kapasitas";
            this.tb_kapasitas.Size = new System.Drawing.Size(189, 31);
            this.tb_kapasitas.TabIndex = 9;
            // 
            // tb_kota
            // 
            this.tb_kota.Location = new System.Drawing.Point(358, 211);
            this.tb_kota.Name = "tb_kota";
            this.tb_kota.Size = new System.Drawing.Size(189, 31);
            this.tb_kota.TabIndex = 10;
            // 
            // tb_manager
            // 
            this.tb_manager.Location = new System.Drawing.Point(358, 255);
            this.tb_manager.Name = "tb_manager";
            this.tb_manager.Size = new System.Drawing.Size(189, 31);
            this.tb_manager.TabIndex = 11;
            // 
            // bt_input
            // 
            this.bt_input.Location = new System.Drawing.Point(358, 302);
            this.bt_input.Name = "bt_input";
            this.bt_input.Size = new System.Drawing.Size(116, 47);
            this.bt_input.TabIndex = 12;
            this.bt_input.Text = "input";
            this.bt_input.UseVisualStyleBackColor = true;
            this.bt_input.Click += new System.EventHandler(this.bt_input_Click);
            // 
            // data
            // 
            this.data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data.Location = new System.Drawing.Point(12, 384);
            this.data.Name = "data";
            this.data.RowHeadersWidth = 82;
            this.data.RowTemplate.Height = 33;
            this.data.Size = new System.Drawing.Size(1443, 469);
            this.data.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1467, 865);
            this.Controls.Add(this.data);
            this.Controls.Add(this.bt_input);
            this.Controls.Add(this.tb_manager);
            this.Controls.Add(this.tb_kota);
            this.Controls.Add(this.tb_kapasitas);
            this.Controls.Add(this.tb_stadium);
            this.Controls.Add(this.tb_tim);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.lbl_manager);
            this.Controls.Add(this.lbl_kota);
            this.Controls.Add(this.lbl_kapasitas);
            this.Controls.Add(this.lbl_stadium);
            this.Controls.Add(this.lbl_nama);
            this.Controls.Add(this.lbl_id);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.Label lbl_nama;
        private System.Windows.Forms.Label lbl_stadium;
        private System.Windows.Forms.Label lbl_kapasitas;
        private System.Windows.Forms.Label lbl_kota;
        private System.Windows.Forms.Label lbl_manager;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.TextBox tb_tim;
        private System.Windows.Forms.TextBox tb_stadium;
        private System.Windows.Forms.TextBox tb_kapasitas;
        private System.Windows.Forms.TextBox tb_kota;
        private System.Windows.Forms.TextBox tb_manager;
        private System.Windows.Forms.Button bt_input;
        private System.Windows.Forms.DataGridView data;
    }
}

