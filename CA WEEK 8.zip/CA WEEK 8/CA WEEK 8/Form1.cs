﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_8
{
    public partial class Form1 : Form
    {
        List<string> data = new List<string>();
        int count = 0;
        OpenFileDialog ofd;
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_baca_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text File (*.txt)|*.txt|All Files (*.*)|*.*";
            ofd.InitialDirectory = "Y:\\note\\";
            ofd.FilterIndex = 2;
            ofd.ShowDialog();
            MessageBox.Show(ofd.FileName);
            
            StreamReader sr = new StreamReader(ofd.FileName);
            string line = sr.ReadLine();
            while (line != null)
            {
                MessageBox.Show(line);
                line = sr.ReadLine();
            }
            sr.Close();

            StreamWriter sw = new StreamWriter(ofd.FileName);
            sw.WriteLine("kevinbucinkartika");
            sw.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bt_previous.Visible = false;
            bt_next.Visible = false;
            bt_kembali.Visible = false;
        }

        private void bt_lihat_Click(object sender, EventArgs e)
        {
            bt_lihat.Visible = false;
            bt_simpan.Visible = false;
            bt_previous.Visible = true;
            bt_next.Visible = true;
            bt_kembali.Visible = true;
            tb_nama.Enabled = false;
            tb_alamat.Enabled = false;
            tb_no.Enabled = false;
            count = 0;
            Split(data[0]);
        }

        private void bt_kembali_Click(object sender, EventArgs e)
        {
            bt_lihat.Visible = true;
            bt_simpan.Visible = true;
            bt_previous.Visible = false;
            bt_next.Visible = false;
            bt_kembali.Visible = false;
            tb_nama.Enabled = true;
            tb_alamat.Enabled = true;
            tb_no.Enabled = true;
            tb_nama.Text = "";
            tb_alamat.Text = "";
            tb_no.Text = "";
        }

        private void bt_simpan_Click(object sender, EventArgs e)
        {
            data.Add(tb_nama.Text + ";" + tb_alamat.Text + ";" + tb_no.Text);
            StreamWriter sw = new StreamWriter(ofd.FileName);
            for (int i = 0; i < data.Count; i++)
            {
                sw.WriteLine(data[i]);
            }
            sw.Close();
            tb_nama.Text = "";
            tb_alamat.Text = "";
            tb_no.Text = "";
        }

        private void bt_file_Click(object sender, EventArgs e)
        {
            ofd = new OpenFileDialog();
            ofd.Filter = "Text File (*.txt)|*.txt|All Files (*.*)|*.*";
            ofd.InitialDirectory = "Y:\\note\\";
            ofd.FilterIndex = 2;
            ofd.ShowDialog();
            StreamReader sr = new StreamReader(ofd.FileName);
            string line = sr.ReadLine();
            
            while (line != null)
            {
                data.Add(line);
                line = sr.ReadLine();
            }
            sr.Close();
        }
        private void Split(string x)
        {
            string[] array = new string[3];
            array = x.Split(';');
            tb_nama.Text = array[0];
            tb_alamat.Text = array[1];
            tb_no.Text = array[2];
        }

        private void bt_next_Click(object sender, EventArgs e)
        {
            count++;
            if (count == data.Count)
            {
                count = count - 1;
            }
            Split(data[count]);
        }

        private void bt_previous_Click(object sender, EventArgs e)
        {
            count--;
            if (count <= 0)
            {
                count = 0;
            }
            Split(data[count]);
        }
    }
}
