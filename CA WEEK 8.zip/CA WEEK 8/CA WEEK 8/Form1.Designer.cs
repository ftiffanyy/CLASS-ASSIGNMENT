﻿namespace CA_WEEK_8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_baca = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_alamat = new System.Windows.Forms.TextBox();
            this.tb_no = new System.Windows.Forms.TextBox();
            this.bt_simpan = new System.Windows.Forms.Button();
            this.bt_lihat = new System.Windows.Forms.Button();
            this.bt_file = new System.Windows.Forms.Button();
            this.bt_previous = new System.Windows.Forms.Button();
            this.bt_next = new System.Windows.Forms.Button();
            this.bt_kembali = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_baca
            // 
            this.bt_baca.Location = new System.Drawing.Point(301, 576);
            this.bt_baca.Name = "bt_baca";
            this.bt_baca.Size = new System.Drawing.Size(158, 100);
            this.bt_baca.TabIndex = 0;
            this.bt_baca.Text = "baca";
            this.bt_baca.UseVisualStyleBackColor = true;
            this.bt_baca.Click += new System.EventHandler(this.bt_baca_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nama";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Alamat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "No Telp";
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(157, 41);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(292, 31);
            this.tb_nama.TabIndex = 4;
            // 
            // tb_alamat
            // 
            this.tb_alamat.Location = new System.Drawing.Point(157, 90);
            this.tb_alamat.Name = "tb_alamat";
            this.tb_alamat.Size = new System.Drawing.Size(292, 31);
            this.tb_alamat.TabIndex = 5;
            // 
            // tb_no
            // 
            this.tb_no.Location = new System.Drawing.Point(157, 134);
            this.tb_no.Name = "tb_no";
            this.tb_no.Size = new System.Drawing.Size(292, 31);
            this.tb_no.TabIndex = 6;
            // 
            // bt_simpan
            // 
            this.bt_simpan.Location = new System.Drawing.Point(157, 189);
            this.bt_simpan.Name = "bt_simpan";
            this.bt_simpan.Size = new System.Drawing.Size(100, 42);
            this.bt_simpan.TabIndex = 7;
            this.bt_simpan.Text = "simpan";
            this.bt_simpan.UseVisualStyleBackColor = true;
            this.bt_simpan.Click += new System.EventHandler(this.bt_simpan_Click);
            // 
            // bt_lihat
            // 
            this.bt_lihat.Location = new System.Drawing.Point(283, 189);
            this.bt_lihat.Name = "bt_lihat";
            this.bt_lihat.Size = new System.Drawing.Size(100, 42);
            this.bt_lihat.TabIndex = 8;
            this.bt_lihat.Text = "lihat";
            this.bt_lihat.UseVisualStyleBackColor = true;
            this.bt_lihat.Click += new System.EventHandler(this.bt_lihat_Click);
            // 
            // bt_file
            // 
            this.bt_file.Location = new System.Drawing.Point(827, 31);
            this.bt_file.Name = "bt_file";
            this.bt_file.Size = new System.Drawing.Size(121, 41);
            this.bt_file.TabIndex = 9;
            this.bt_file.Text = "file";
            this.bt_file.UseVisualStyleBackColor = true;
            this.bt_file.Click += new System.EventHandler(this.bt_file_Click);
            // 
            // bt_previous
            // 
            this.bt_previous.Location = new System.Drawing.Point(157, 189);
            this.bt_previous.Name = "bt_previous";
            this.bt_previous.Size = new System.Drawing.Size(120, 42);
            this.bt_previous.TabIndex = 10;
            this.bt_previous.Text = "previous";
            this.bt_previous.UseVisualStyleBackColor = true;
            this.bt_previous.Click += new System.EventHandler(this.bt_previous_Click);
            // 
            // bt_next
            // 
            this.bt_next.Location = new System.Drawing.Point(283, 189);
            this.bt_next.Name = "bt_next";
            this.bt_next.Size = new System.Drawing.Size(100, 42);
            this.bt_next.TabIndex = 11;
            this.bt_next.Text = "next";
            this.bt_next.UseVisualStyleBackColor = true;
            this.bt_next.Click += new System.EventHandler(this.bt_next_Click);
            // 
            // bt_kembali
            // 
            this.bt_kembali.Location = new System.Drawing.Point(389, 189);
            this.bt_kembali.Name = "bt_kembali";
            this.bt_kembali.Size = new System.Drawing.Size(117, 42);
            this.bt_kembali.TabIndex = 12;
            this.bt_kembali.Text = "kembali";
            this.bt_kembali.UseVisualStyleBackColor = true;
            this.bt_kembali.Click += new System.EventHandler(this.bt_kembali_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 532);
            this.Controls.Add(this.bt_kembali);
            this.Controls.Add(this.bt_next);
            this.Controls.Add(this.bt_previous);
            this.Controls.Add(this.bt_file);
            this.Controls.Add(this.bt_lihat);
            this.Controls.Add(this.bt_simpan);
            this.Controls.Add(this.tb_no);
            this.Controls.Add(this.tb_alamat);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_baca);
            this.Name = "Form1";
            this.Text = "abcd";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_baca;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_alamat;
        private System.Windows.Forms.TextBox tb_no;
        private System.Windows.Forms.Button bt_simpan;
        private System.Windows.Forms.Button bt_lihat;
        private System.Windows.Forms.Button bt_file;
        private System.Windows.Forms.Button bt_previous;
        private System.Windows.Forms.Button bt_next;
        private System.Windows.Forms.Button bt_kembali;
    }
}

