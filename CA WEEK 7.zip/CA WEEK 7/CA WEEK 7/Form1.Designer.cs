﻿namespace CA_WEEK_7
{
    partial class Formmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datatim = new System.Windows.Forms.DataGridView();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.bt_delete = new System.Windows.Forms.Button();
            this.cb_tim1 = new System.Windows.Forms.ComboBox();
            this.cb_tim2 = new System.Windows.Forms.ComboBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.tb_kiri = new System.Windows.Forms.TextBox();
            this.tb_kanan = new System.Windows.Forms.TextBox();
            this.bt_match = new System.Windows.Forms.Button();
            this.bt_team = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datatim)).BeginInit();
            this.SuspendLayout();
            // 
            // datatim
            // 
            this.datatim.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datatim.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.datatim.Location = new System.Drawing.Point(42, 43);
            this.datatim.MultiSelect = false;
            this.datatim.Name = "datatim";
            this.datatim.RowHeadersWidth = 82;
            this.datatim.RowTemplate.Height = 33;
            this.datatim.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datatim.Size = new System.Drawing.Size(1265, 452);
            this.datatim.TabIndex = 0;
            // 
            // datetime
            // 
            this.datetime.Location = new System.Drawing.Point(295, 533);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(410, 31);
            this.datetime.TabIndex = 1;
            // 
            // bt_delete
            // 
            this.bt_delete.Location = new System.Drawing.Point(42, 510);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(138, 54);
            this.bt_delete.TabIndex = 2;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = true;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // cb_tim1
            // 
            this.cb_tim1.FormattingEnabled = true;
            this.cb_tim1.Location = new System.Drawing.Point(295, 594);
            this.cb_tim1.Name = "cb_tim1";
            this.cb_tim1.Size = new System.Drawing.Size(188, 33);
            this.cb_tim1.TabIndex = 3;
            this.cb_tim1.SelectedIndexChanged += new System.EventHandler(this.cb_tim1_SelectedIndexChanged);
            // 
            // cb_tim2
            // 
            this.cb_tim2.FormattingEnabled = true;
            this.cb_tim2.Location = new System.Drawing.Point(577, 594);
            this.cb_tim2.Name = "cb_tim2";
            this.cb_tim2.Size = new System.Drawing.Size(180, 33);
            this.cb_tim2.TabIndex = 4;
            this.cb_tim2.SelectedIndexChanged += new System.EventHandler(this.cb_tim2_SelectedIndexChanged);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(506, 590);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(48, 37);
            this.lbl1.TabIndex = 5;
            this.lbl1.Text = "vs";
            // 
            // tb_kiri
            // 
            this.tb_kiri.Location = new System.Drawing.Point(295, 660);
            this.tb_kiri.Name = "tb_kiri";
            this.tb_kiri.Size = new System.Drawing.Size(188, 31);
            this.tb_kiri.TabIndex = 6;
            this.tb_kiri.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_kiri_KeyPress);
            // 
            // tb_kanan
            // 
            this.tb_kanan.Location = new System.Drawing.Point(577, 660);
            this.tb_kanan.Name = "tb_kanan";
            this.tb_kanan.Size = new System.Drawing.Size(180, 31);
            this.tb_kanan.TabIndex = 7;
            this.tb_kanan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_kanan_KeyPress);
            // 
            // bt_match
            // 
            this.bt_match.Location = new System.Drawing.Point(345, 718);
            this.bt_match.Name = "bt_match";
            this.bt_match.Size = new System.Drawing.Size(138, 54);
            this.bt_match.TabIndex = 8;
            this.bt_match.Text = "Add Match";
            this.bt_match.UseVisualStyleBackColor = true;
            this.bt_match.Click += new System.EventHandler(this.bt_match_Click);
            // 
            // bt_team
            // 
            this.bt_team.Location = new System.Drawing.Point(540, 718);
            this.bt_team.Name = "bt_team";
            this.bt_team.Size = new System.Drawing.Size(138, 54);
            this.bt_team.TabIndex = 9;
            this.bt_team.Text = "Add Team";
            this.bt_team.UseVisualStyleBackColor = true;
            this.bt_team.Click += new System.EventHandler(this.bt_team_Click);
            // 
            // Formmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1357, 830);
            this.Controls.Add(this.bt_team);
            this.Controls.Add(this.bt_match);
            this.Controls.Add(this.tb_kanan);
            this.Controls.Add(this.tb_kiri);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.cb_tim2);
            this.Controls.Add(this.cb_tim1);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.datetime);
            this.Controls.Add(this.datatim);
            this.Name = "Formmain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Formmain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datatim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView datatim;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.ComboBox cb_tim1;
        private System.Windows.Forms.ComboBox cb_tim2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox tb_kiri;
        private System.Windows.Forms.TextBox tb_kanan;
        private System.Windows.Forms.Button bt_match;
        private System.Windows.Forms.Button bt_team;
    }
}

