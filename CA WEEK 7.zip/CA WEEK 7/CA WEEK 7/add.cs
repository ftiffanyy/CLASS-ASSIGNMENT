﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_7
{
    public partial class add : Form
    {
        Formmain form;
        public add()
        {
            InitializeComponent();
        }

        private void add_Load(object sender, EventArgs e)
        {

        }
        public add(Form _sender)
        {
            InitializeComponent();
            form = (Formmain) _sender;
        }
        private void bt_add_Click(object sender, EventArgs e)
        {
            form.Addteam(tb_name.Text);
            this.Close();
        }
    }
}
