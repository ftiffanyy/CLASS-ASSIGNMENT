﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_7
{
    public partial class Formmain : Form
    {
        DataTable dttim;
        DataTable dtnama;
        DataTable dtnama2;
        add add;
        public Formmain()
        {
            InitializeComponent();
        }

        private void Formmain_Load(object sender, EventArgs e)
        {
            dttim = new DataTable();
            dttim.Columns.Add("Match Date");
            dttim.Columns.Add("Home Team");
            dttim.Columns.Add("Home Score");
            dttim.Columns.Add("Away Score");
            dttim.Columns.Add("Away Team");
            datatim.DataSource = dttim;

            dtnama = new DataTable();
            dtnama.Columns.Add("Team Name");
            dtnama.Rows.Add("Boston Celtics");
            dtnama.Rows.Add("Indiana Pacers");
            dtnama.Rows.Add("Cleveland Cavaliers");
            dtnama.Rows.Add("Golden State Warriors");
            dtnama.Rows.Add("Los Angeles Lakers");
            dtnama.Rows.Add("Los Angeles Clippers");
            dtnama.Rows.Add("Houston Rockets");
            dtnama.Rows.Add("Charlotte Hornets");
            dtnama.Rows.Add("Miami Heat");
            dtnama.Rows.Add("Chicago Bulls");
            dtnama.Rows.Add("Atlanta Hawks");
            

            dtnama2 = new DataTable();
            dtnama2.Columns.Add("Team Name");
            dtnama2.Rows.Add("Boston Celtics");
            dtnama2.Rows.Add("Indiana Pacers");
            dtnama2.Rows.Add("Cleveland Cavaliers");
            dtnama2.Rows.Add("Golden State Warriors");
            dtnama2.Rows.Add("Los Angeles Lakers");
            dtnama2.Rows.Add("Los Angeles Clippers");
            dtnama2.Rows.Add("Houston Rockets");
            dtnama2.Rows.Add("Charlotte Hornets");
            dtnama2.Rows.Add("Miami Heat");
            dtnama2.Rows.Add("Chicago Bulls");
            dtnama2.Rows.Add("Atlanta Hawks");

            for ( int i = 0; i < dtnama.Rows.Count; i++ )
            {
                cb_tim1.Items.Add(dtnama.Rows[i][0].ToString());
            }
            for (int i = 0; i < dtnama2.Rows.Count; i++)
            {
                cb_tim2.Items.Add(dtnama2.Rows[i][0].ToString());
            }
            cb_tim1.SelectedIndex = -1;
            cb_tim2.SelectedIndex = -1;
        }

        private void cb_tim1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_tim1.SelectedIndex == -1)
            {

            }
            else
            {
                string select = cb_tim1.SelectedItem.ToString();
                for (int i = 0; i < dtnama2.Rows.Count; i++)
                {
                    if (dtnama2.Rows[i][0].ToString() == select)
                    {
                        dtnama2.Rows.Remove(dtnama2.Rows[i]);
                    }
                }
                cb_tim2.Items.Clear();
                for (int i = 0; i < dtnama2.Rows.Count; i++)
                {
                    cb_tim2.Items.Add(dtnama2.Rows[i][0].ToString());
                }
            }
        }

        private void tb_kiri_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            if ((sender as TextBox).TextLength >= 3 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_kanan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            if ((sender as TextBox).TextLength >= 3 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cb_tim2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_tim2.SelectedIndex == -1)
            {

            }
            else
            {
                string select = cb_tim2.SelectedItem.ToString();
                for (int i = 0; i < dtnama.Rows.Count; i++)
                {
                    if (dtnama.Rows[i][0].ToString() == select)
                    {
                        dtnama.Rows.Remove(dtnama.Rows[i]);
                    }
                }
                cb_tim1.Items.Clear();
                for (int i = 0; i < dtnama.Rows.Count; i++)
                {
                    cb_tim1.Items.Add(dtnama.Rows[i][0].ToString());
                }
            }
            /*
            if (cb_tim1.SelectedIndex == -1)
            {

            }
            else if (cb_tim2.SelectedIndex != -1)
            {
                for (int i = 0; i < dtnama.Rows.Count; i++)
                {
                    if (dtnama.Rows[i][0].ToString() == cb_tim2.Text)
                    {
                        dtnama.Rows.RemoveAt(i);
                    }
                }
                cb_tim1.DataSource = dtnama;
                cb_tim1.DisplayMember = "Team Name";
            }
            */
        }

        private void bt_match_Click(object sender, EventArgs e)
        {
            string date = datetime.Value.ToString();
            dttim.Rows.Add(date, cb_tim1.Text, tb_kiri.Text, tb_kanan.Text, cb_tim2.Text);
            datatim.DataSource = dttim;
            cb_tim1.SelectedIndex = -1;
            cb_tim2.SelectedIndex = -1;
        }

        private void bt_team_Click(object sender, EventArgs e)
        {
            add = new add(this);
            add.Show();
        }
        public void Addteam(string name)
        {
            bool yn = true;
            for(int i = 0;i < dtnama.Rows.Count;i++)
            {
                if (dtnama.Rows[i][0].ToString().ToLower() == name.ToLower())
                {
                    yn = false; break;
                }
            }
            bool tf = true;
            for (int i = 0; i < dtnama2.Rows.Count; i++)
            {
                if (dtnama2.Rows[i][0].ToString().ToLower() == name.ToLower())
                {
                    yn = false; break;
                }
            }
            if (yn == false || tf == false)
            {
                MessageBox.Show("ERROR");
            }
            else if (yn == true && tf == true)
            {
                dtnama.Rows.Add(name);
                dtnama2.Rows.Add(name);
                cb_tim1.Items.Clear();
                cb_tim2.Items.Clear();
                for (int i = 0; i < dtnama.Rows.Count; i++)
                {
                    cb_tim1.Items.Add(dtnama.Rows[i][0].ToString());
                }
                for (int i = 0; i < dtnama2.Rows.Count; i++)
                {
                    cb_tim2.Items.Add(dtnama2.Rows[i][0].ToString());
                }
            }
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            int index = -1;
            if (datatim.SelectedCells.Count > 0)
            {
                index = datatim.SelectedCells[0].RowIndex;
            }
            dttim.Rows.RemoveAt(index);
            datatim.DataSource = dttim;
        }
    }
}
