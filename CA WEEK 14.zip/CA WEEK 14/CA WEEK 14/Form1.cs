﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_WEEK_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dt; DataTable dtteam; DataTable dtaway; DataTable player; 
        string query; string idhome; string idaway; string idteam; int index;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =student;" + "pwd=isbmantap;" + "database=premier_league");
            dtteam = new DataTable(); dtaway = new DataTable();
            query = "select team_id, team_name from team t";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam); sqlDataAdapter.Fill(dtaway);
            cb_home.DataSource = dtteam;
            cb_home.DisplayMember = "team_name";
            cb_home.ValueMember = "team_id";
            cb_away.DataSource = dtaway;
            cb_away.DisplayMember = "team_name";
            cb_away.ValueMember = "team_id";
            cb_home.SelectedIndex = -1;
            cb_away.SelectedIndex = -1;
            dt = new DataTable();
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");
        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex == -1 && cb_away.SelectedIndex == -1)
            {
                
            }
            else
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home dan Team Away tidak boleh sama");
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_home.SelectedValue);
                    idaway = Convert.ToString(cb_away.SelectedValue);
                    cb_team.Items.Add(cb_home.Text);
                    cb_team.Items.Add(cb_away.Text);
                }
            }
        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_home.SelectedIndex == -1 && cb_away.SelectedIndex == -1)
            {

            }
            else
            {
                if (cb_away.Text == cb_home.Text)
                {
                    MessageBox.Show("Team Home dan Team Away tidak boleh sama");
                }
                else
                {
                    cb_team.Items.Clear();
                    idhome = Convert.ToString(cb_home.SelectedValue);
                    idaway = Convert.ToString(cb_away.SelectedValue);
                    cb_team.Items.Add(cb_home.Text);
                    cb_team.Items.Add(cb_away.Text);
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            if (cb_team.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if (cb_team.SelectedIndex == 1)
            {
                idteam = idaway;
            }
            query = $"select player_id, player_name from player where team_id like '%{idteam}%'";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
        }

        private void date_ValueChanged(object sender, EventArgs e)
        {
            DataTable count = new DataTable();
            string year = date.Value.Year.ToString();
            query = $"select count(match_id) from `match` where match_id like '{year}%';";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(count);

            if (Convert.ToInt32(count.Rows[0][0]) < 10)
            {
                tb_id.Text = $"{year}00{(Convert.ToInt32(count.Rows[0][0]) + 1).ToString()}";
            }
            else if (Convert.ToInt32(count.Rows[0][0]) >= 10 && Convert.ToInt32(count.Rows[0][0]) < 100)
            {
                tb_id.Text = $"{year}0{(Convert.ToInt32(count.Rows[0][0]) + 1).ToString()}";
            }
            else if (Convert.ToInt32(count.Rows[0][0]) >= 100)
            {
                tb_id.Text = $"{year}{(Convert.ToInt32(count.Rows[0][0]) + 1).ToString()}";
            }
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
            dgv.DataSource = dt;
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv.DataSource = dt;
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void bt_insert_Click(object sender, EventArgs e)
        {
            //insert dmatch
            try
            {
                foreach()
                query = $"insert into dmatch values ({tb_id.Text}, {tb_minute.Text}, {idhome}, {cb_player.SelectedValue}, {cb_type.SelectedValue}, '0' )';";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //insert match
            foreach (DataRow dr in dt.Rows)
            {
                if()
            }
            try
            {
                query = $"insert into `match` values ({tb_id.Text}, {date.Value}, {idhome}, {idaway}, goalhome, goal away, 'M002', '0');";
                sqlCommand = new MySqlCommand(query, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
