﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_WEEK_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server =localhost;" + "uid =student;" + "pwd=isbmantap;" + "database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            // 1 string query = "select t.team_name, count(d.team_id) as 'Jumlah Goal' from team t, dmatch d where t.team_id = d.team_id and (d.type = 'GO' or d.type = 'GP') group by d.team_id order by 2 desc;";
            // 2 string query = "select t.team_name, count(d.team_id) as 'Goal Penalty' from team t, dmatch d where t.team_id = d.team_id and d.type = 'GP' group by d.team_id order by 2 desc;";
            // 3 string query = "select d.minute, count(d.type) as 'Jumlah Goal' from dmatch d where d.type = 'GO' or d.type = 'GP' group by d.minute order by 2 desc;";
            // 4 string query = "select n.nation as Nationality, count(p.nationality_id) as `Jumlah Pemain` from nationality n, player p where p.nationality_id = n.nationality_id group by p.nationality_id having `Jumlah Pemain` < 4 order by 2 desc;";
            string query = "select p.player_name as 'Nama Pemain', count(d.type) as 'Jumlah Gol' from player p join dmatch d on p.player_id = d.player_id where p.team_number < 6 and p.playing_pos = 'D' group by 1 order by 2 desc;";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            dgv.DataSource = dt;
        }
    }
}
