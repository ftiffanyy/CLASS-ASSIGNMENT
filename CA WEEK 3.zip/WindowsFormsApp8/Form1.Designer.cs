﻿namespace WindowsFormsApp8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_age = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.tb_age = new System.Windows.Forms.TextBox();
            this.rb_male = new System.Windows.Forms.RadioButton();
            this.rb_female = new System.Windows.Forms.RadioButton();
            this.lbl_colors = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb_red = new System.Windows.Forms.RadioButton();
            this.rb_yellow = new System.Windows.Forms.RadioButton();
            this.rb_green = new System.Windows.Forms.RadioButton();
            this.lbl_hobbies = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tb_hobi = new System.Windows.Forms.TextBox();
            this.cb_read = new System.Windows.Forms.CheckBox();
            this.cb_tv = new System.Windows.Forms.CheckBox();
            this.cb_sport = new System.Windows.Forms.CheckBox();
            this.lbl_hobi = new System.Windows.Forms.Label();
            this.bt_submit = new System.Windows.Forms.Button();
            this.bt_clear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(77, 22);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(50, 16);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "Name :";
            // 
            // lbl_age
            // 
            this.lbl_age.AutoSize = true;
            this.lbl_age.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_age.Location = new System.Drawing.Point(89, 49);
            this.lbl_age.Name = "lbl_age";
            this.lbl_age.Size = new System.Drawing.Size(38, 16);
            this.lbl_age.TabIndex = 1;
            this.lbl_age.Text = "Age :";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gender.Location = new System.Drawing.Point(69, 77);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(58, 16);
            this.lbl_gender.TabIndex = 2;
            this.lbl_gender.Text = "Gender :";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(133, 22);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(100, 20);
            this.tb_name.TabIndex = 3;
            // 
            // tb_age
            // 
            this.tb_age.Location = new System.Drawing.Point(133, 49);
            this.tb_age.Name = "tb_age";
            this.tb_age.Size = new System.Drawing.Size(100, 20);
            this.tb_age.TabIndex = 4;
            // 
            // rb_male
            // 
            this.rb_male.AutoSize = true;
            this.rb_male.Location = new System.Drawing.Point(13, 6);
            this.rb_male.Name = "rb_male";
            this.rb_male.Size = new System.Drawing.Size(48, 17);
            this.rb_male.TabIndex = 5;
            this.rb_male.TabStop = true;
            this.rb_male.Text = "Male";
            this.rb_male.UseVisualStyleBackColor = true;
            // 
            // rb_female
            // 
            this.rb_female.AutoSize = true;
            this.rb_female.Location = new System.Drawing.Point(13, 29);
            this.rb_female.Name = "rb_female";
            this.rb_female.Size = new System.Drawing.Size(59, 17);
            this.rb_female.TabIndex = 6;
            this.rb_female.TabStop = true;
            this.rb_female.Text = "Female";
            this.rb_female.UseVisualStyleBackColor = true;
            // 
            // lbl_colors
            // 
            this.lbl_colors.AutoSize = true;
            this.lbl_colors.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_colors.Location = new System.Drawing.Point(23, 129);
            this.lbl_colors.Name = "lbl_colors";
            this.lbl_colors.Size = new System.Drawing.Size(104, 16);
            this.lbl_colors.TabIndex = 7;
            this.lbl_colors.Text = "Favorite Colors :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rb_male);
            this.panel1.Controls.Add(this.rb_female);
            this.panel1.Location = new System.Drawing.Point(133, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(75, 52);
            this.panel1.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb_green);
            this.panel2.Controls.Add(this.rb_red);
            this.panel2.Controls.Add(this.rb_yellow);
            this.panel2.Location = new System.Drawing.Point(133, 135);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(100, 73);
            this.panel2.TabIndex = 9;
            // 
            // rb_red
            // 
            this.rb_red.AutoSize = true;
            this.rb_red.Location = new System.Drawing.Point(13, 6);
            this.rb_red.Name = "rb_red";
            this.rb_red.Size = new System.Drawing.Size(45, 17);
            this.rb_red.TabIndex = 5;
            this.rb_red.TabStop = true;
            this.rb_red.Text = "Red";
            this.rb_red.UseVisualStyleBackColor = true;
            // 
            // rb_yellow
            // 
            this.rb_yellow.AutoSize = true;
            this.rb_yellow.Location = new System.Drawing.Point(13, 29);
            this.rb_yellow.Name = "rb_yellow";
            this.rb_yellow.Size = new System.Drawing.Size(56, 17);
            this.rb_yellow.TabIndex = 6;
            this.rb_yellow.TabStop = true;
            this.rb_yellow.Text = "Yellow";
            this.rb_yellow.UseVisualStyleBackColor = true;
            // 
            // rb_green
            // 
            this.rb_green.AutoSize = true;
            this.rb_green.Location = new System.Drawing.Point(13, 52);
            this.rb_green.Name = "rb_green";
            this.rb_green.Size = new System.Drawing.Size(54, 17);
            this.rb_green.TabIndex = 7;
            this.rb_green.TabStop = true;
            this.rb_green.Text = "Green";
            this.rb_green.UseVisualStyleBackColor = true;
            // 
            // lbl_hobbies
            // 
            this.lbl_hobbies.AutoSize = true;
            this.lbl_hobbies.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hobbies.Location = new System.Drawing.Point(69, 224);
            this.lbl_hobbies.Name = "lbl_hobbies";
            this.lbl_hobbies.Size = new System.Drawing.Size(65, 16);
            this.lbl_hobbies.TabIndex = 10;
            this.lbl_hobbies.Text = "Hobbies :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbl_hobi);
            this.panel3.Controls.Add(this.cb_sport);
            this.panel3.Controls.Add(this.cb_tv);
            this.panel3.Controls.Add(this.cb_read);
            this.panel3.Controls.Add(this.tb_hobi);
            this.panel3.Location = new System.Drawing.Point(133, 214);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(177, 100);
            this.panel3.TabIndex = 10;
            // 
            // tb_hobi
            // 
            this.tb_hobi.Location = new System.Drawing.Point(60, 75);
            this.tb_hobi.Name = "tb_hobi";
            this.tb_hobi.Size = new System.Drawing.Size(100, 20);
            this.tb_hobi.TabIndex = 11;
            // 
            // cb_read
            // 
            this.cb_read.AutoSize = true;
            this.cb_read.Location = new System.Drawing.Point(13, 9);
            this.cb_read.Name = "cb_read";
            this.cb_read.Size = new System.Drawing.Size(66, 17);
            this.cb_read.TabIndex = 12;
            this.cb_read.Text = "Reading";
            this.cb_read.UseVisualStyleBackColor = true;
            // 
            // cb_tv
            // 
            this.cb_tv.AutoSize = true;
            this.cb_tv.Location = new System.Drawing.Point(13, 30);
            this.cb_tv.Name = "cb_tv";
            this.cb_tv.Size = new System.Drawing.Size(89, 17);
            this.cb_tv.TabIndex = 13;
            this.cb_tv.Text = "Watching TV";
            this.cb_tv.UseVisualStyleBackColor = true;
            // 
            // cb_sport
            // 
            this.cb_sport.AutoSize = true;
            this.cb_sport.Location = new System.Drawing.Point(13, 53);
            this.cb_sport.Name = "cb_sport";
            this.cb_sport.Size = new System.Drawing.Size(93, 17);
            this.cb_sport.TabIndex = 14;
            this.cb_sport.Text = "Playing Sports";
            this.cb_sport.UseVisualStyleBackColor = true;
            // 
            // lbl_hobi
            // 
            this.lbl_hobi.AutoSize = true;
            this.lbl_hobi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hobi.Location = new System.Drawing.Point(11, 76);
            this.lbl_hobi.Name = "lbl_hobi";
            this.lbl_hobi.Size = new System.Drawing.Size(43, 15);
            this.lbl_hobi.TabIndex = 11;
            this.lbl_hobi.Text = "Other :";
            // 
            // bt_submit
            // 
            this.bt_submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_submit.Location = new System.Drawing.Point(133, 323);
            this.bt_submit.Name = "bt_submit";
            this.bt_submit.Size = new System.Drawing.Size(79, 32);
            this.bt_submit.TabIndex = 11;
            this.bt_submit.Text = "Submit";
            this.bt_submit.UseVisualStyleBackColor = true;
            this.bt_submit.Click += new System.EventHandler(this.bt_submit_Click);
            // 
            // bt_clear
            // 
            this.bt_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_clear.Location = new System.Drawing.Point(218, 323);
            this.bt_clear.Name = "bt_clear";
            this.bt_clear.Size = new System.Drawing.Size(79, 32);
            this.bt_clear.TabIndex = 12;
            this.bt_clear.Text = "Clear";
            this.bt_clear.UseVisualStyleBackColor = true;
            this.bt_clear.Click += new System.EventHandler(this.bt_clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 367);
            this.Controls.Add(this.bt_clear);
            this.Controls.Add(this.bt_submit);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbl_hobbies);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbl_colors);
            this.Controls.Add(this.tb_age);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.lbl_age);
            this.Controls.Add(this.lbl_name);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_age;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.TextBox tb_age;
        private System.Windows.Forms.RadioButton rb_male;
        private System.Windows.Forms.RadioButton rb_female;
        private System.Windows.Forms.Label lbl_colors;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rb_green;
        private System.Windows.Forms.RadioButton rb_red;
        private System.Windows.Forms.RadioButton rb_yellow;
        private System.Windows.Forms.Label lbl_hobbies;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_hobi;
        private System.Windows.Forms.CheckBox cb_sport;
        private System.Windows.Forms.CheckBox cb_tv;
        private System.Windows.Forms.CheckBox cb_read;
        private System.Windows.Forms.TextBox tb_hobi;
        private System.Windows.Forms.Button bt_submit;
        private System.Windows.Forms.Button bt_clear;
    }
}

