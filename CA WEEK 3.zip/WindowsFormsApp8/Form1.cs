﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_submit_Click(object sender, EventArgs e)
        {
            string nama = tb_name.Text;
            string age = "";
            string gender = "";
            bool checkhobi = false;
            List<string> hobi = new List<string>();
            foreach (char x in nama)
            {
                if (char.IsDigit(x))
                {
                    MessageBox.Show("Check Textbox Name");
                }
            }
            foreach (char y in tb_age.Text)
            {
                if (char.IsDigit(y))
                {
                    age += y;
                }
                else
                {
                    MessageBox.Show("Check Textbox Age");
                }
            }
            if (nama == "" || age == "")
            {
                MessageBox.Show("Textbox kosong");
            }
            if (rb_male.Checked)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }
            if (cb_read.Checked)
            {
                hobi.Add("Reading");
            }
            if (cb_tv.Checked)
            {
                hobi.Add("Watching TV");
            }
            if (cb_sport.Checked)
            {
                hobi.Add("Playing Sports");
            }
            if (tb_hobi.Text != "")
            {
                foreach (char x in tb_hobi.Text)
                {
                    if (char.IsDigit(x))
                    {
                        MessageBox.Show("Check Textbox Other");
                    }
                    else
                    {
                        checkhobi = true;
                    }
                }
                if (checkhobi = true)
                {
                    hobi.Add(tb_hobi.Text);
                }
            }
            string total = "";
            for (int i = 0; i < hobi.Count; i++)
            {
                total += hobi[i];
                if (i == hobi.Count - 1)
                {
                    total += "";
                }
                else if (hobi.Count > 2)
                {
                    total += ", ";
                }
                else if (hobi.Count == 2)
                {
                    total += " and ";
                }
            }
            if (nama != "" || age != "")
            {
                MessageBox.Show("Name : " + nama + " Age : " + age + " Gender : " + gender + " Hobbies : " + total);
                if (rb_red.Checked)
                {
                    this.BackColor = Color.Red;
                }
                if (rb_yellow.Checked)
                {
                    this.BackColor = Color.Yellow;
                }
                if (rb_green.Checked)
                {
                    this.BackColor = Color.Green;
                }
            }
        }

        private void bt_clear_Click(object sender, EventArgs e)
        {
            tb_name.Text = "";
            tb_age.Text = "";
            rb_male.Checked = false;   
            rb_female.Checked = false;
            rb_red.Checked = false;
            rb_yellow.Checked = false;
            rb_green.Checked = false;
            cb_read.Checked = false;
            cb_tv.Checked = false;
            cb_sport.Checked = false;
            tb_hobi.Text = "";
            this.BackColor = Color.White;
        }
    }
}
